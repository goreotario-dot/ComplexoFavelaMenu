package com.example.complexofavelamenu

import android.app.Activity
import android.os.Bundle
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.animation.ValueAnimator
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(9, 13, 16)
    private val panel = Color.rgb(19, 28, 30)
    private var neon = Color.rgb(0, 255, 145)
    private val prefs by lazy { getSharedPreferences("favela_demo", Context.MODE_PRIVATE) }
    private lateinit var status: TextView
    private lateinit var menu: LinearLayout
    private lateinit var radar: RadarView
    private lateinit var espSwitch: Switch
    private lateinit var aimSwitch: Switch
    private lateinit var profileSpinner: Spinner
    private lateinit var themeSpinner: Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val root = FrameLayout(this).apply { setBackgroundColor(bg) }
        val scroll = ScrollView(this)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(20, 26, 20, 30)
        }
        scroll.addView(page)
        root.addView(scroll, FrameLayout.LayoutParams(-1, -1))

        page.addView(TextView(this).apply {
            text = "COMPLEXO FAVELA"
            textSize = 25f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            gravity = Gravity.CENTER
        }, matchWrap())
        page.addView(TextView(this).apply {
            text = "NEON CONTROL • DEMO 3.0"
            textSize = 11f
            setTextColor(neon)
            gravity = Gravity.CENTER
            setPadding(0, 6, 0, 16)
        }, matchWrap())

        val dashboard = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(12, 12, 12, 12)
            background = rounded(panel, 16)
        }
        val clock = TextClock(this).apply {
            format12Hour = "hh:mm:ss a"
            format24Hour = "HH:mm:ss"
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        }
        dashboard.addView(clock, LinearParams(0, -2, 1f))
        val battery = TextView(this).apply {
            textSize = 12f
            setTextColor(neon)
            gravity = Gravity.END
            val intent = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val level = intent?.getIntExtra("level", -1) ?: -1
            val scale = intent?.getIntExtra("scale", 100) ?: 100
            text = if (level >= 0) "BATERIA: ${level * 100 / scale}%" else "BATERIA: --"
        }
        dashboard.addView(battery, LinearParams(0, -2, 1f))
        page.addView(dashboard, matchWrap())

        menu = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 16, 16, 16)
            background = rounded(panel, 20)
        }
        val menuParams = matchWrap().apply { topMargin = 14 }
        page.addView(menu, menuParams)

        status = TextView(this).apply {
            text = "STATUS: MENU PRONTO"
            textSize = 12f
            setTextColor(neon)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, 10)
        }
        menu.addView(status, matchWrap())

        espSwitch = addToggle(menu, "ESP VISUAL (DEMO)", "Indicadores fictícios, sem conexão com o jogo.", "esp")
        aimSwitch = addToggle(menu, "AIM ASSIST (DEMO)", "Apenas controle ilustrativo; não mira no jogo.", "aim")

        menu.addView(sectionTitle("RADAR DEMONSTRATIVO"), matchWrap())
        radar = RadarView(this)
        menu.addView(radar, LinearParams(-1, 210, 1f))

        val zoomLabel = TextView(this).apply {
            text = "ZOOM DO RADAR: 100%"
            textSize = 12f
            setTextColor(Color.WHITE)
            setPadding(0, 8, 0, 2)
        }
        menu.addView(zoomLabel, matchWrap())
        val zoom = SeekBar(this).apply {
            max = 150
            progress = 50
            progressTintList = android.content.res.ColorStateList.valueOf(neon)
            thumbTintList = android.content.res.ColorStateList.valueOf(neon)
        }
        menu.addView(zoom, matchWrap())
        zoom.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) {
                val percent = 50 + p
                zoomLabel.text = "ZOOM DO RADAR: ${percent}%"
                radar.zoom = percent / 100f
                radar.invalidate()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        val rotate = Switch(this).apply {
            text = "ROTAÇÃO DO RADAR"
            setTextColor(Color.WHITE)
            thumbTintList = android.content.res.ColorStateList.valueOf(neon)
            setOnCheckedChangeListener { _, checked -> radar.setRotating(checked) }
        }
        menu.addView(rotate, matchWrap())

        menu.addView(sectionTitle("PERFIS E APARÊNCIA"), matchWrap())
        profileSpinner = spinner(listOf("Padrão", "Competitivo", "Treino"))
        menu.addView(profileSpinner, matchWrap())
        themeSpinner = spinner(listOf("Verde neon", "Azul neon", "Roxo neon"))
        menu.addView(themeSpinner, matchWrap())
        themeSpinner.setSelection(prefs.getInt("theme", 0).coerceIn(0, 2))
        themeSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                neon = when (position) {
                    1 -> Color.rgb(0, 190, 255)
                    2 -> Color.rgb(190, 90, 255)
                    else -> Color.rgb(0, 255, 145)
                }
                refreshAccent()
            }
        }

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val save = actionButton("SALVAR PERFIL") {
            val name = profileSpinner.selectedItemPosition
            prefs.edit()
                .putBoolean("esp_$name", espSwitch.isChecked)
                .putBoolean("aim_$name", aimSwitch.isChecked)
                .putInt("theme", themeSpinner.selectedItemPosition)
                .putInt("zoom_$name", zoom.progress)
                .apply()
            status.text = "STATUS: PERFIL ${profileSpinner.selectedItem} SALVO"
        }
        val load = actionButton("CARREGAR") {
            val name = profileSpinner.selectedItemPosition
            espSwitch.isChecked = prefs.getBoolean("esp_$name", false)
            aimSwitch.isChecked = prefs.getBoolean("aim_$name", false)
            zoom.progress = prefs.getInt("zoom_$name", 50).coerceIn(0, 150)
            status.text = "STATUS: PERFIL ${profileSpinner.selectedItem} CARREGADO"
        }
        actions.addView(save, LinearParams(0, -2, 1f))
        actions.addView(load, LinearParams(0, -2, 1f))
        menu.addView(actions, matchWrap())

        menu.addView(actionButton("RESTAURAR PADRÕES") {
            espSwitch.isChecked = false
            aimSwitch.isChecked = false
            zoom.progress = 50
            profileSpinner.setSelection(0)
            themeSpinner.setSelection(0)
            status.text = "STATUS: PADRÕES RESTAURADOS"
        }, matchWrap())

        menu.addView(TextView(this).apply {
            text = "FPS: 60 (SIMULADO)  •  RADAR COM ALVOS FICTÍCIOS\nApp independente: não acessa nem modifica o Complexo Favela."
            textSize = 10f
            setTextColor(Color.LTGRAY)
            setPadding(2, 12, 2, 0)
        }, matchWrap())

        val floating = TextView(this).apply {
            text = "CF"
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.BLACK)
            background = rounded(neon, 100)
            elevation = 14f
            setOnClickListener { toggleMenu() }
            setOnTouchListener(object : View.OnTouchListener {
                var downX = 0f; var downY = 0f
                var startX = 0f; var startY = 0f
                var moved = false
                override fun onTouch(v: View, e: MotionEvent): Boolean {
                    val lp = v.layoutParams as FrameLayout.LayoutParams
                    when (e.action) {
                        MotionEvent.ACTION_DOWN -> {
                            downX = e.rawX; downY = e.rawY
                            startX = lp.rightMargin.toFloat(); startY = lp.bottomMargin.toFloat()
                            moved = false
                            return false
                        }
                        MotionEvent.ACTION_MOVE -> {
                            val dx = e.rawX - downX; val dy = e.rawY - downY
                            if (kotlin.math.abs(dx) > 8 || kotlin.math.abs(dy) > 8) moved = true
                            if (moved) {
                                lp.rightMargin = (startX - dx).toInt().coerceAtLeast(0)
                                lp.bottomMargin = (startY - dy).toInt().coerceAtLeast(0)
                                v.layoutParams = lp
                                return true
                            }
                        }
                        MotionEvent.ACTION_UP -> if (moved) return true
                    }
                    return false
                }
            })
        }
        root.addView(floating, FrameLayout.LayoutParams(58, 58, Gravity.END or Gravity.BOTTOM).apply {
            setMargins(0, 0, 20, 22)
        })

        setContentView(root)
        espSwitch.isChecked = prefs.getBoolean("esp_0", false)
        aimSwitch.isChecked = prefs.getBoolean("aim_0", false)
        updateStatus()
    }

    private fun addToggle(parent: LinearLayout, label: String, detail: String, key: String): Switch {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 6, 0, 8)
        }
        val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        line.addView(TextView(this).apply {
            text = label; textSize = 13f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
        }, LinearParams(0, -2, 1f))
        val sw = Switch(this).apply {
            isChecked = prefs.getBoolean("${key}_0", false)
            thumbTintList = android.content.res.ColorStateList.valueOf(neon)
            setOnCheckedChangeListener { _, _ -> updateStatus() }
        }
        line.addView(sw)
        row.addView(line, matchWrap())
        row.addView(TextView(this).apply { text = detail; textSize = 11f; setTextColor(Color.LTGRAY) }, matchWrap())
        parent.addView(row, matchWrap())
        return sw
    }

    private fun toggleMenu() {
        if (menu.visibility != View.VISIBLE) {
            menu.visibility = View.VISIBLE
            menu.alpha = 0f
            menu.scaleX = .94f
            menu.scaleY = .94f
            menu.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(220)
                .setInterpolator(AccelerateDecelerateInterpolator()).start()
        } else {
            menu.animate().alpha(0f).scaleX(.94f).scaleY(.94f).setDuration(160)
                .withEndAction { menu.visibility = View.GONE; menu.alpha = 1f; menu.scaleX = 1f; menu.scaleY = 1f }.start()
        }
    }

    private fun updateStatus() {
        if (::status.isInitialized && ::espSwitch.isInitialized && ::aimSwitch.isInitialized) {
            status.text = "ESP: ${if (espSwitch.isChecked) "ON" else "OFF"}  •  AIM: ${if (aimSwitch.isChecked) "ON" else "OFF"}"
        }
    }

    private fun refreshAccent() {
        if (::radar.isInitialized) radar.invalidate()
    }

    private fun spinner(items: List<String>) = Spinner(this).apply {
        adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
    }

    private fun sectionTitle(s: String) = TextView(this).apply {
        text = s; textSize = 13f; setTextColor(neon); typeface = Typeface.DEFAULT_BOLD
        setPadding(0, 15, 0, 6)
    }

    private fun actionButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label; textSize = 10f; setTextColor(Color.BLACK)
        backgroundTintList = android.content.res.ColorStateList.valueOf(neon)
        setOnClickListener { action() }
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = radius.toFloat()
    }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
    private fun LinearParams(w: Int, h: Int, weight: Float) = LinearLayout.LayoutParams(w, h, weight)

    private class RadarView(context: Context) : View(context) {
        var zoom = 1f
        private var angle = 0f
        private var animator: ValueAnimator? = null
        private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(0, 170, 100); style = Paint.Style.STROKE; strokeWidth = 2f
        }
        private val faint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(0, 90, 60); style = Paint.Style.STROKE; strokeWidth = 1.2f
        }
        private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(0, 255, 145); style = Paint.Style.FILL }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val cx = width / 2f; val cy = height / 2f
            val radius = minOf(width, height) * .36f * zoom.coerceIn(.5f, 2f)
            canvas.drawColor(Color.rgb(7, 17, 15))
            canvas.save()
            canvas.rotate(angle, cx, cy)
            canvas.drawCircle(cx, cy, radius, ring)
            canvas.drawCircle(cx, cy, radius * .66f, faint)
            canvas.drawCircle(cx, cy, radius * .33f, faint)
            canvas.drawLine(cx-radius, cy, cx+radius, cy, faint)
            canvas.drawLine(cx, cy-radius, cx, cy+radius, faint)
            canvas.drawLine(cx, cy, cx+radius, cy-radius*.25f, ring)
            val points = listOf(-.48f to -.25f, .42f to -.52f, .58f to .24f, -.2f to .58f)
            points.forEach { (x, y) -> canvas.drawCircle(cx + x*radius, cy + y*radius, 5f, dot) }
            canvas.restore()
            canvas.drawCircle(cx, cy, 5f, dot)
        }
        fun setRotating(enabled: Boolean) {
            animator?.cancel()
            if (enabled) {
                animator = ValueAnimator.ofFloat(angle, angle + 360f).apply {
                    duration = 8000L; repeatCount = ValueAnimator.INFINITE
                    addUpdateListener { angle = it.animatedValue as Float; invalidate() }
                    start()
                }
            }
        }
        override fun onDetachedFromWindow() {
            animator?.cancel()
            super.onDetachedFromWindow()
        }
    }
}
