# Complexo Favela Menu — Demo Android Neon 3.0

Recursos:
- interface neon com animação de abrir/fechar;
- botão CF flutuante e arrastável dentro da tela do app;
- radar local fictício com zoom e rotação;
- perfis Padrão, Competitivo e Treino, com salvar/carregar;
- temas verde, azul e roxo neon;
- restaurar padrões;
- painel com relógio, bateria e FPS simulado.

**Importante:** protótipo independente. Não se conecta ao Complexo Favela, não lê/altera memória de outros apps, não injeta código e não automatiza vantagens no jogo.

## Gerar APK
1. Extraia o ZIP e abra a pasta no Android Studio.
2. Aguarde a sincronização do Gradle (JDK 17).
3. Instale o Android SDK 35, se solicitado.
4. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK de teste: `app/build/outputs/apk/debug/app-debug.apk`.
